#include <stdio.h>

int main(void)
{
    putchar(0x0d);
    putchar(0x0a);
    putchar('h');
    putchar('e');
    putchar('l');
    putchar('l');
    putchar('o');
    putchar(',');
    putchar('E');
    putchar('M');
    putchar('U');
    putchar('Z');
    putchar('8');
    putchar('0');
    putchar('-');
    putchar('6');
    putchar('5');
    putchar('0');
    putchar('2');
    return 0;
}
