#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define N (256)

int main(int argc, char *argv[])
{
    FILE *fp;
    char str[N];
    char dst[N];
    char addr[N];
    int nbyte, i;

    if (argc != 2) {
        printf("usage: %s file.hex\n", argv[0]);
        exit(1);
    }

    fp = fopen(argv[1],"r");
    if (fp == NULL) {
        printf("%s can not open\n", argv[1]);
        exit(1);
    }
    while ( fgets(str, N, fp) != NULL ) {
        strncpy(dst, str+1, 2);
        dst[2]='\0';
        sscanf(dst,"%x",&nbyte);
        strncpy(addr, str+3, 4);
        addr[4]='\0';
        if (strcmp(addr, "0000") == 0 ) {
            break;
        }
        printf("%s: ",addr);
        for (i=0; i<nbyte; i++) {
            strncpy(dst, str+9+i*2, 2);
            dst[2]='\0';
            printf("%s ", dst);
        }
        printf("\n");
    }
    fclose(fp);
    return 0;
}
