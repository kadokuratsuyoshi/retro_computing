#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BUFFER_SIZE (4096)

int main(int argc, char **argv){
	int buffer_size = BUFFER_SIZE;
	int len, i, c;
	unsigned char sum;
	char *buffer;
	char *in_file = NULL;
	char *out_file = NULL;
	FILE *in = stdin;
	FILE *out = stdout;
	
	if(argc > 1){
		if(memcmp(argv[1], "-h", 3) == 0){
			fprintf(stderr, "usage: hex2bin [OPTION] FILE or hex2bin < IN [ > OUT]\n");
			fprintf(stderr, "OPTION:\n"
							"    -s [size]     : buffer size. (default: %dbyte)\n"
							"    -i [IN] : input file path. (if you use STDIN, do not use this option)\n"
							"    -o [OUT] : output file path.\n", BUFFER_SIZE);
			fprintf(stderr, "IN : input file path.\n");
			fprintf(stderr, "OUT: output file path.\n");
			return 0;
		}
		// arg
		while(argc > 2){
			if(memcmp(argv[1], "-s", 3) == 0){
				buffer_size = atoi(argv[2]);
				argv+=2;
				argc--;
			}else if(memcmp(argv[1], "-o", 3) == 0){
				out_file = argv[2];
				if((out=fopen(out_file, "wb")) == NULL){
					fprintf(stderr, "can't open file: %s\n", out_file);
					return -1;
				}
				argv+=2;
				argc--;
			}else if(memcmp(argv[1], "-i", 3)==0){
				in_file = argv[2];
				argv+=2;
				argc--;
			}
			argc--;
		}
		
		if(in_file == NULL && argc>1) in_file = argv[1];
		
		if(in_file!=NULL){
			if((in=fopen(in_file, "rb")) == NULL){
				fprintf(stderr, "can't open file: %s\n", in_file);
				return -1;
			}
		}
	}
	
	if(buffer_size < 1) buffer_size = BUFFER_SIZE;
	if((buffer = (char *)malloc(buffer_size)) == NULL){
		fprintf(stderr, "Buffer allocation failed : size=%d\n", buffer_size);
		return -1;
	}

/*
	fprintf(stderr, "buffer size: %dbyte\n", buffer_size);
	if(in != stdin) fprintf(stderr, "input: %s\n", in_file);
	if(out != stdout) fprintf(stderr, "output: %s\n", out_file);
*/

	c=0; sum=0;
	while(len = fread(buffer, 1, buffer_size, in)){
		for(i=0; i<len; ++i){
			if(buffer[i] >='0' && buffer[i] <= '9'){
				sum *= 16;
				sum += buffer[i] -'0';
				c++;
			}else if(buffer[i] >='A' && buffer[i] <= 'F'){
				sum *= 16;
				sum += buffer[i] -'A'+10;
				c++;
			}else if(buffer[i] >='a' && buffer[i] <= 'f'){
				sum *= 16;
				sum += buffer[i]-'a'+10;
				c++;
			}
			
			if(c==2){
				fwrite(&sum, 1, 1, out);
				c=0; sum=0;
			}
		}
	}
	
	fclose(in);
	fclose(out);
	return 0;
}
